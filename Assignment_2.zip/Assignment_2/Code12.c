// Write a C program to input month number and print number of days in that month.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int month;
    printf("Enter the month number\n");
    scanf("%d", &month);

    if (month == 1 || month == 3 || month == 5 || month == 7 || month == month == 8 || month == 10 || month == 12)
    {
        printf("31 Days\n");
    }

    else if (month == 2)
    {
        printf("28 Days\n");
    }

    else
    {
        printf("30 Days\n");
    }

    return 0;
}