// Write a C program to check whether a character is uppercase or lowercase alphabet.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    char c;
    printf("Enter the Alphabet: \n");
    scanf("%c", &c);

    if (c >= 'a' && c <= 'z')
    {
        printf("LOWER CASE ALPHABET\n");
    }

    if (c >= 'A' && c <= 'Z')
    {
        printf("UPPER CASE ALPHABET\n");
    }

    else
    {
        printf("Invalid Character");
    }

    return 0;
}