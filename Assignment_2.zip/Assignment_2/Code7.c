// Write a C program to check whether a character is alphabet or not.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    char c;
    printf("Enter The Charater: \n");
    scanf("%c", &c);

    if (c >= 'a' && c <= 'z')
    {
        printf("ALPHABET\n");
    }

    else if (c >= 'A' && c <= 'Z')
    {
        printf("ALPHABET\n");
    }

    else
    {
        printf("NOT AN ALPHABET\n");
    }

    return 0;
}