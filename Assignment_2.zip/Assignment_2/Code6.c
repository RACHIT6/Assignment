// Write a C program to check whether a year is leap year or not.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int year;
    printf("Enter the Year: \n");
    scanf("%d", &year);

    if (year % 4 == 0)
    {
        printf("LEAP YEAR\n");
    }

    else if (year % 400 == 0)
    {
        printf("LEAP YEAR\n");
    }

    else
    {
        printf("NOT A LEAP YEAR\n");
    }

    return 0;
}