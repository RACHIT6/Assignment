/*Write a C program to input marks of five subjects Physics, Chemistry, Biology,
Mathematics and Computer. Calculate percentage and grade according to
following:
Percentage >= 90% : Grade A
Percentage >= 80% : Grade B
Percentage >= 70% : Grade C
Percentage >= 60% : Grade D
Percentage >= 40% : Grade E
Percentage < 40% : Grade F*/
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int P, C, B, M, Com;

    printf("Please enter the marks of subjects following: \n");
    printf("Physics\nChemistry\nBiology\nMathematics\nComputer\n\n");

    printf("Enter the marks of Physics: ");
    scanf("%d", &P);

    printf("Enter the marks of Chemistry: ");
    scanf("%d", &C);

    printf("Enter the marks of Biology: ");
    scanf("%d", &B);

    printf("Enter the marks of Maths: ");
    scanf("%d", &M);

    printf("Enter the marks of Computer: ");
    scanf("%d", &Com);

    printf("<<<<<<<<<<<<<<<<<<<<<..........Result..........>>>>>>>>>>>>>>>>>>>>>\n\n");
    float per = ((float)(P + C + B + M + Com) / 500) * 100;

    if (per < 40.00)
    {
        printf("You go F grade and Your percantage is %.2f%%\n", per);
    }

    else if (per >= 40.00)
    {
        printf("You go E grade and Your percantage is %.2f%%\n", per);
    }

    else if (per >= 60.00)
    {
        printf("You go D grade and Your percantage is %.2f%%\n", per);
    }

    else if (per >= 70.00)
    {
        printf("You go C grade and Your percantage is %.2f%%\n", per);
    }

    else if (per >= 80.00)
    {
        printf("You go B grade and Your percantage is %.2f%%\n", per);
    }

    else if (per >= 90.00)
    {
        printf("You go A grade and Your percantage is %.2f%%\n", per);
    }

    return 0;
}