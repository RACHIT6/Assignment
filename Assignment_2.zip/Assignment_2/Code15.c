// Write a C program to find all roots of a quadratic equation.
#include<stdio.h>
#include<math.h>

int main(int argc, char const *argv[])
{
    float a, b, c;
    float D;
    printf("Enter the cofficient of x^2: ");
    scanf("%f", &a);
    printf("Enter the cofficient of x: ");
    scanf("%f", &b);
    printf("Enter the constant: ");
    scanf("%f", &c);

    D = b*b - 4 * a * c;
    printf("%f\n", D);

    if (D <= 0)
    {
        printf("Roots are Imaginary\n");
    }
        
    else
    {
        float r1, r2, temp = sqrt(D);
        printf("%f\n", temp);
        r1 = (-b + temp)/(2*a);
        r2 = (-b - temp)/(2*a);

        printf("First root: %0.3f\n", r1);
        printf("Second root: %0.3f\n", r2);
    }   

    return 0;
}