// # Write a C program to input any character and check whether it is alphabet, digit or special character.
#include<stdio.h>

int main(int argc, char const *argv[])
{
    char c;
    printf("Enter a Character: \n");
    scanf("%c", &c);

    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
    {
        printf("ALPHABET\n");
    }
    
    else if (c >= '0' && c <= '9')
    {
        printf("DIGIT\n");
    }
    
    else
    {
        printf("SPECIAL CHARACTER\n");
    }
    
    return 0;
}