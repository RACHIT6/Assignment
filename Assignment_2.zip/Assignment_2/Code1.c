// # Write a C program to find maximum between two numbers.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n1, n2;
    printf("Enter First Number: \n");
    scanf("%d", &n1);

    printf("Enter Second Number: \n");
    scanf("%d", &n2);

    // BT TERNARY
    (n1 > n2) ? printf("The first number %d is Greater\n", n1) : printf("The second number %d is Greater\n", n2);

    // BY IF-ELSE
    // if (n1 > n2)
    // {
    //     printf("%d is Greater\n", n1);
    // }

    // else
    // {
    //     printf("%d is greater\n", n2);
    // }

    return 0;
}