// # Write a C program to check whether a number is negative, positive or zero.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter a Number: \n");
    scanf("%d", &n);

    // BY TERNARY OPERATOR
    // (n >= 0)?(n == 0)?printf("Zero\n"):printf("POSITIVE\n"):printf("NEGATIVE\n");

    // BY IF-ELSE
    if (n > 0)
    {
        printf("POSITIVE\n");
    }

    else if (n == 0)
    {
        printf("Zero\n");
    }

    else
    {
        printf("NEGATIVE\n");
    }

    return 0;
}