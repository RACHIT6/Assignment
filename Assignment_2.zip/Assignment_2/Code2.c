// # Write a C program to find maximum between three numbers.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n1, n2, n3;

    printf("Enter First Number: \n");
    scanf("%d", &n1);

    printf("Enter Second Number: \n");
    scanf("%d", &n2);

    printf("Enter Third Number: \n");
    scanf("%d", &n3);

    //BY IF-ELSE
    // if (n1 > n2 && n1 > n3)
    // {
    //     printf("First number is greater\n");
    // }

    // if (n2 > n1 && n2 > n3)
    // {
    //     printf("Second number is greater\n");
    // }

    // if (n3 > n2 && n3 > n1)
    // {
    //     printf("Third number is greater\n");
    // }

    // BY TERNARY OPERATOR

    (n1 > n2) ? (n1 > n3) ? printf("First number is greater\n") : printf("Third number is greater\n") : printf("Second number is greater\n");
    // (n2 > n1)?(n2 > n3)?printf("Second number is greater\n"):printf("Third number is greater\n");

    return 0;
}