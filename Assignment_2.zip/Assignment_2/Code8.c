// Write a C program to input any alphabet and check whether it is vowel or consonant.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    char c;
    printf("Enter a Alphabet: \n");
    scanf("%c", &c);

    if (c == 'a' || c == 'i' || c == 'o' || c == 'u' || c == 'e' || c == 'A' || c == 'I' || c == 'O' || c == 'U' || c == 'E')
    {
        printf("VOWEL\n");
    }

    else
    {
        printf("CONSONANT\n");
    }

    return 0;
}