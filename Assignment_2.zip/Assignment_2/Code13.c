// Write a C program to input all sides of a triangle and check whether triangle is valid or not.
#include<stdio.h>

int main(int argc, char const *argv[])
{
    int s1, s2, s3;
    printf("Enter the sides of triangle\n");
    scanf("%d", &s1);
    scanf("%d", &s2);
    scanf("%d", &s3);

    if (s1 + s2 > s3 && s2 + s3 > s1 && s1 + s3 > s2)
    {
        printf("VALID TRIANGLE\n");
    }
    
    else
    {
        printf("INVALID TRIANGLE\n");
    }

    return 0;
}