// Write a C program to check whether a number is even or odd.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the number: ");
    scanf("%d", &n);

    if (n % 2 == 0)
    {
        printf("EVEN\n");
    }

    else
    {
        printf("ODD\n");
    }

    return 0;
}