// WAP to input an array of N number of elements. Input the position of element you want to delete. Print the element deleted and updated array after deletion of that element.
#include <stdio.h>
int size;

void deletion(int arr[], int index)
{

    for (int i = index; i < size; i++)
    {
        arr[i] = arr[i + 1];
    }

    size--;
}

void tranversal(int arr[])
{
    printf("\nPrinted array:");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
}

int main(int argc, char const *argv[])
{
    printf("Enter the size of array: ");
    scanf("%d", &size);
    int arr[size];

    for (int i = 0; i < size; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int E;

    printf("Enter the no element to want to delete\n");
    scanf("%d", &E);

    int index;
    for (int i = 0; i < E; i++)
    {
        printf("Enter the index to delete the element\n");
        scanf("%d", &index);
        deletion(arr, index);
    }

    tranversal(arr);

    return 0;
}