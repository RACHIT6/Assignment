
#include <stdio.h>
int size;

void deletion(int arr[], int index)
{

    for (int i = index; i < size; i++)
    {
        arr[i] = arr[i + 1];
    }

    size--;
}

void tranversal(int arr[])
{
    printf("\nPrinted array:");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
}

int main(int argc, char const *argv[])
{
    printf("Enter the size of array: ");
    scanf("%d", &size);
    int arr[size];

    for (int i = 0; i < size; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int val, index = -1;
    printf("Enter the value to delete\n");
    scanf("%d", &val);

    for (int i = 0; i < size; i++)
    {
        if (arr[i] == val)
        {
            index = i;
            break;
        }
    }

    if (index == -1)
    {
        printf("Value not found\n");
    }

    else
    {
        deletion(arr, index);
        tranversal(arr);
    }

    return 0;
}