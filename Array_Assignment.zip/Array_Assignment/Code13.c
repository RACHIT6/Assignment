// 13.WAP to input an array of N number of distinct elements. Input an element you want to search and find it. If found then print the position of that element otherwise print not found.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    printf("******Enter differnt element of array******\n\n");

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int val;
    int free = -1;
    printf("Enter the element you want to find\n");
    scanf("%d", &val);

    for (int i = 0; i < n; i++)
    {
        if (val == arr[i])
        {
            free = i;
            break;
        }
    }

    if (free == -1)
    {
        printf("Element not fonud\n");
    }

    else
    {
        printf("The %d element is present on %d index\n", val, free);
    }

    return 0;
}