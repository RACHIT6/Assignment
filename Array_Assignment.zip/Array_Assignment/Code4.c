// 4.WAP to input an array of N number of elements and count total number of positives, negatives and zero elements in that array and display those counts.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n, pos = 0, neg = 0, zero = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);

        if (arr[i] > zero)
        {
            pos++;
        }

        else if (arr[i] < 0)
        {
            neg++;
        }

        else
        {
            zero++;
        }
    }

    printf("POSITIVE NUMBER = %d\n", pos);
    printf("NEGATIVE NUMBER = %d\n", neg);
    printf("ZERO = %d\n", zero);

    return 0;
}