// WAP to input an array of N number of elements (Elements can repeat) . Input an element you want to search and find it. If found then print all the positions of that element otherwise print not found.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];
    int index[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int val, j = 0;
    int free = -1;
    printf("Enter the element you want to find\n");
    scanf("%d", &val);

    for (int i = 0; i < n; i++)
    {
        if (val == arr[i])
        {
            index[j] = i;
            free = i;
            j++;
        }
    }

    if (free == -1)
    {
        printf("Element not fonud\n");
    }

    else
    {
        printf("The index where %d element is found are:\n", val);

        for (int i = 0; i < j; i++)
        {
            printf("%d\n", index[i]);
        }
    }

    return 0;
}