// 27.WAP to input an array of N elements and delete all the elements from that array which are perfect number.
#include <stdio.h>

int n;

void deletion(int arr[], int index)
{

    for (int i = index; i < n; i++)
    {
        arr[i] = arr[i + 1];
    }

    n--;
}

int isPerfert(int n)
{
    int sum = 0;

    for (int i = 1; i <= n / 2; i++)
    {
        if (n % i == 0)
        {
            sum += i;
        }
    }

    if (sum == n)
    {
        return 1;
    }
    
    return 0;
}

int main(int argc, char const *argv[])
{
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    for (int i = 0; i < n; i++)
    {
        if (isPerfert(arr[i]))
        {
            deletion(arr, i);
        }
        
    }
    

    printf("\nPrinted array:");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}