// WAP to input an array of N number of elements and store all even numbers in 1 array and all odd numbers in another array. Print both the even and odd array separately.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n, val, j = 0, z = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int even[n], odd[n];
    printf("Enter the element:\n");

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &val);
        if (val % 2 == 0)
        {
            even[j] = val;
            j++;
        }

        else
        {
            odd[z] = val;
            z++;
        }
    }

    printf("\nEven Array: ");
    for (int i = 0; i < j; i++)
    {
        printf("%d ", even[i]);
    }

    printf("\nOdd Array: ");
    for (int i = 0; i < z; i++)
    {
        printf("%d ", odd[i]);
    }

    return 0;
}