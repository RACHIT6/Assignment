// WAP to input an array of N number of elements and find the second smallest element and 2nd largest element in that array.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int small = arr[n - 1];
    int large = arr[0];
    int small_2;
    int large_2;

    for (int i = 0; i < n; i++)
    {
        if (small > arr[i])
        {
            small_2 = small;
            small = arr[i];
        }
        if (large < arr[i])
        {
            large_2 = large;
            large = arr[i];
        }

        else if (arr[i] < small_2 && arr[i] != small)
        {
            small_2 = arr[i];
        }
    }

    printf("2nd SMALLEST: %d\n", small_2);
    printf("2nd LARGEST: %d\n", large_2);

    return 0;
}