// WAP to input an array of N number of elements. Input E no. of elements you want to insert in that array along with their positions and insert all of them. Print the final array after insertion of all elements.
#include <stdio.h>
int size;

void insertion(int arr[], int index, int val)
{

    for (int i = size - 1; i >= index; i--)
    {
        arr[i + 1] = arr[i];
    }

    arr[index] = val;
    size++;
}

void tranversal(int arr[])
{
    printf("\nPrinted array:");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
}

int main(int argc, char const *argv[])
{
    printf("Enter the size of array: ");
    scanf("%d", &size);
    int arr[size];

    for (int i = 0; i < size; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int E;
    printf("Enter no of element you want to insert\n");
    scanf("%d", &E);

    int val, index;

    for (int i = 0; i < E; i++)
    {
        printf("Enter the %d element to want to enter\n", i + 1);
        scanf("%d", &val);
        printf("Enter the index to insert the element\n");
        scanf("%d", &index);
        printf("\n\n\n");

        insertion(arr, index, val);
    }

    tranversal(arr);
    return 0;
}