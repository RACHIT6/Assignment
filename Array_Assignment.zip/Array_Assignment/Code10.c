// 10.WAP to input an array of N number of elements and find the smallest element in that array.
#include<stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }
    
    int smallest = arr[0];

    for (int i = 0; i < n; i++)
    {
        if (arr[i] < smallest)
        {
            smallest = arr[i];
        }
        
    }
    
    printf("The smallest element is %d\n", smallest);

    return 0;
}