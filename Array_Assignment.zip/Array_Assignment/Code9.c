// 9.WAP to input an array of N number of elements and find the largest element in that array.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n, largest = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);

        if (arr[i] > largest)
        {
            largest = arr[i];
        }
    }

    printf("The largest no in array is %d\n", largest);

    return 0;
}