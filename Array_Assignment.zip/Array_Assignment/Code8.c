// WAP to read the marks of 500 students of a course in computer programming and print the frequency of each score above 60. Do it using most efficient method you could taking minimum memory and minimum time.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n, count = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d student marks\n", i + 1);
        scanf("%d", &arr[i]);

        if (arr[i] > 60)
        {
            count++;
        }
    }

    printf("FREQUENCY(Marks above 60): %d\n", count);

    return 0;
}