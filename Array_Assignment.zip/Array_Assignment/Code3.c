// WAP to input an array of N number of elements and find the sum and average of all the elements of that array.
#include<stdio.h>

int main(int argc, char const *argv[])
{
    int n, sum = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
        sum += arr[i];
    }

    printf("The sum and average is %d and %d\n", sum, sum/n);

    return 0;
}