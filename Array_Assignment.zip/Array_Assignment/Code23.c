/*23.WAP to input an array of N number of elements. Right rotate this array by R number of rotations and print the final array.
Example:- Suppose array is               4    5    3    9   1
After Right rotation by 1 it will be   1    4     5    3   9*/
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int temp = arr[n - 1];
    for (int i = n - 1; i > 0; i--)
    {
        arr[i] = arr[i - 1];
    }
    arr[0] = temp;

    printf("\nPrinted array:");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}