// 16.WAP to input an array of N number of elements and sort it in descending order using bubble sort.
#include<stdio.h>

void Bubble_sort(int arr[], int size){
    int temp, car = 1;

    for (int i = 0; i < size; i++)
    {
        car = 1;
        for (int j = 0; j < size - 1 - i; j++)
        {
            if (arr[j] < arr[j + 1])
            {
                car = 0;
                temp = arr[j +1];
                arr[j + 1] = arr[j];
                arr[j] = temp;   
            }
            
        }
        
        if (car == 1)
        {
            return;
        }
        
    }
    
}

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    Bubble_sort(arr, n);

    printf("\nPrinted array in ascending: ");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}