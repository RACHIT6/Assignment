//  WAP to input an array of N number of elements and find the frequency of all elements in that array.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int ind = 1, var = -1;
    int indo[n];

    printf("\nPrinted Element Frequency:\n");
    for (int i = 0; i < n; i++)
    {
        ind = 1;
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] == arr[j])
            {
                ind++;
                arr[j] = var;
            }
        }
        if (indo[i] != var)
        {
            indo[i] = ind;
        }
    }

    for (int i = 0; i < n; i++)
    {
        if (arr[i] != var)
        {
            printf("%d\t", arr[i]);
            printf("%d\n", indo[i]);
        }
    }

    return 0;
}