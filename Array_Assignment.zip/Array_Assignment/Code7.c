// Suppose there is president election in US and there are 2 candidates Trump and Biden. Input the votes of both the candidates in 10 states of US and calculate state-wise winner and overall winner.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int state = 10, count_t = 0, count_b = 0;
    int trump[state], biden[state];

    for (int i = 0; i < state; i++)
    {
        printf("Enter %d state votes of Trump\n", i + 1);
        scanf("%d", &trump[i]);
        printf("Enter %d state votes of Biden\n", i + 1);
        scanf("%d", &biden[i]);

        if (trump[i] > biden[i])
        {
            printf("Trump win in %d state\n", i + 1);
            count_t++;
        }

        else if (trump[i] == biden[i])
        {
            printf("DRAW");
        }

        else
        {
            printf("Biden win in %d state\n", i + 1);
            count_b++;
        }
    }

    printf("\n\n RESULT: ");

    if (count_b > count_t)
    {
        printf("Biden wins the elections\n");
    }

    else if (count_b == count_t)
    {
        printf("DRAW");
    }

    else
    {
        printf("Trump wins the elections\n");
    }

    return 0;
}