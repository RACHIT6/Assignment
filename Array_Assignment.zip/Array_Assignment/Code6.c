// 6.WAP to input an array of N number of elements and find their standard deviation.
#include<stdio.h>
#include<math.h>

int main(int argc, char const *argv[])
{
    int n, sum = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
        sum += arr[i];
    }

    int mean = sum/n;
    int x2;
    int sum1 = 0;
    printf("\n", mean);
    for (int i = 0; i < n; i++)
    {
        x2 = pow(mean - arr[i], 2);
        sum1 += x2;
    }
    
    float dev_m = (float)sum1/n;
    printf("%.2f\n", sqrt(dev_m));

    return 0;
}