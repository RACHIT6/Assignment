// WAP to input an array of N number of elements and display it in reverse order.
#include<stdio.h>

int main(int argc, char const *argv[])
{
    int n, temp;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    printf("\nPrinted Reversed Array:");
    for (int i = 0; i < n/2; i++)
    {
        temp = arr[n - i -1];
        arr[n - i -1] = arr[i];
        arr[i] = temp;
    }

    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }   

    return 0;
}