// 11.WAP to input an array of N number of elements and swap the largest and smallest element in that array and print the updated array.
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    printf("\n\nORIGINAL: ");

    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    int largest = 0, ns, nL;
    int smallest = arr[0];

    for (int i = 0; i < n; i++)
    {
        if (arr[i] < smallest)
        {
            smallest = arr[i];
            ns = i;
        }

        if (arr[i] > largest)
        {
            largest = arr[i];
            nL = i;
        }
    }

    int temp = arr[ns];
    arr[ns] = arr[nL];
    arr[nL] = temp;

    printf("\n\nRESULT: ");

    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}