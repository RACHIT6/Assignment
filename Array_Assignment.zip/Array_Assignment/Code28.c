// WAP to input an array of N number of elements and delete all the duplicate elements from that array.
#include <stdio.h>

int n;

void deletion(int arr[], int index)
{

    for (int i = index; i < n ; i++)
    {
        arr[i] = arr[i + 1];
    }

    n--;
}

int main(int argc, char const *argv[])
{
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            
            if (arr[i] == arr[j])
            {
                deletion(arr, j);
                j--;
            }
        }
    }

    printf("\nPrinted array:");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}