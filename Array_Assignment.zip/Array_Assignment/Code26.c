// WAP to input an array of N number of elements . Traverse this array from starting to end , if element found is prime then convert it into palindrome number next to it and if its not prime(composite) then convert it into next Armstrong number. print the updated array.
#include <stdio.h>
#include <math.h>

int isprime(int n)
{
    for (int i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return 0;
        }
    }

    return 1;
}

int iscomposite(int n)
{
    for (int i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return 1;
        }
    }

    return 0;
}

int Arm(int n)
{
    int n1 = n;
    int n3 = n;
    int power;
    int count = 0, temp;
    int arm, sum = 0;

    while (n1 != 0)
    {
        count++;
        n1 /= 10;
    }

    while (n != 0)
    {
        temp = n % 10;
        power = pow(temp, count);
        arm = power;
        sum += arm;
        n /= 10;
    }

    if (n3 == sum)
    {
        return 1;
    }

    else
    {
        return 0;
    }
}

int isArmstrong(int n)
{
    if (n < 10)
    {
        return n;
    }

    else
    {
        for (int i = n; 1; i++)
        {
            if (Arm(i))
            {
                return i;
            }
        }
    }
}

int reverse(int n)
{
    int n1 = n;
    int reverse = 0, temp;

    while (n != 0)
    {
        temp = n % 10;
        reverse = reverse * 10 + temp;
        n /= 10;
    }

    if (n1 == reverse)
    {
        return 1;
    }

    return 0;
}

int palindrome(int n)
{
    if (n < 10)
    {
        return n;
    }

    else
    {
        for (int i = n; 1; i++)
        {
            if (reverse(i))
            {
                return i;
            }
        }
    }
}

void tranversal(int arr[], int size)
{
    printf("\nPrinted array:");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
}

int main(int argc, char const *argv[])
{
    int n;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    for (int i = 0; i < n; i++)
    {
        if (isprime(arr[i]))
        {
            arr[i] = palindrome(arr[i]);
        }

        else if (iscomposite(arr[i]))
        {
            arr[i] = isArmstrong(arr[i]);
        }
    }

    tranversal(arr, n);

    return 0;
}