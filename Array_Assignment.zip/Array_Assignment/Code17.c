// 17.WAP to input an array of N number of elements. Input an element you want to insert in that array along with the position and insert it. Print the final array after insertion.
#include<stdio.h>
int size;

void insertion(int arr[], int index, int val){

    for (int i = size - 1; i >= index; i--)
    {
        arr[i + 1] = arr[i];
    }
    
    arr[index] = val;
    size++;
}

void tranversal(int arr[])
{
    printf("\nPrinted array:");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
}

int main(int argc, char const *argv[])
{
    printf("Enter the size of array: ");
    scanf("%d", &size);
    int arr[size];

    for (int i = 0; i < size; i++)
    {
        printf("Enter %d element of array\n", i + 1);
        scanf("%d", &arr[i]);
    }

    int val, index;
    printf("Enter the element to want to enter\n");
    scanf("%d", &val);
    printf("Enter the index to insert the element\n");
    scanf("%d", &index);
    insertion(arr, index, val);
    tranversal(arr);

    return 0;
}